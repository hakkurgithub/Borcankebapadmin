---
name: "Adana Kebap"
description: "Acılı kıyma ile hazırlanmış geleneksel Adana kebabı"
price: 65
category: "Kebap"
image: "https://raw.githubusercontent.com/hakkurgithub/images/main/adana-porsiyon.jpg"
calories: 480
isVegetarian: false
isVegan: false
isGlutenFree: true
isActive: true
---

# Adana Kebap

Acılı kıyma ile hazırlanmış geleneksel Adana kebabı.

## İçindekiler
- Acılı kuzu kıyması
- Közlenmiş domates ve biber
- Bulgur pilavı
- Közlenmiş patlıcan
- Acılı ezme