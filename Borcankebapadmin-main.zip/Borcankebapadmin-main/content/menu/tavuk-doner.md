---
name: "Tavuk Döner"
description: "Marine edilmiş tavuk göğsünden hazırlanan sağlıklı döner alternatifi"
price: 40
category: "Döner"
image: "https://raw.githubusercontent.com/hakkurgithub/images/main/tavuk-doner.jpg"
calories: 350
isVegetarian: false
isVegan: false
isGlutenFree: false
isActive: true
---

# Tavuk Döner

Marine edilmiş tavuk göğsünden hazırlanan sağlıklı döner alternatifi.

## İçindekiler
- Marine edilmiş tavuk göğsü
- Taze yeşillikler
- Domates
- Salatalık
- Özel yoğurt sosu