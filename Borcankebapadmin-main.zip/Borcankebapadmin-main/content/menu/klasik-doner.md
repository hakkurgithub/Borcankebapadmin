---
name: "Klasik Döner"
description: "Geleneksel döner usulü hazırlanmış, taze sebzelerle servis edilen klasik dönerimiz"
price: 45
category: "Döner"
image: "https://raw.githubusercontent.com/hakkurgithub/images/main/doner-kebap.jpg"
calories: 420
isVegetarian: false
isVegan: false
isGlutenFree: false
isActive: true
---

# Klasik Döner

Geleneksel döner usulü hazırlanmış, taze sebzelerle servis edilen klasik dönerimiz.

## İçindekiler
- Kuzu ve dana karışımı döner eti
- Taze salata
- Domates
- Soğan
- Turşu
- Özel sos