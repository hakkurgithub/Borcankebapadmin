---
name: "Karışık Pide"
description: "Kaşar peyniri, sucuk, yumurta ve sebzelerle hazırlanmış nefis pide"
price: 55
category: "Pide"
image: "https://raw.githubusercontent.com/hakkurgithub/images/main/karisik-pide.jpeg"
calories: 520
isVegetarian: false
isVegan: false
isGlutenFree: false
isActive: true
---

# Karışık Pide

Kaşar peyniri, sucuk, yumurta ve sebzelerle hazırlanmış nefis pide.

## İçindekiler
- Kaşar peyniri
- Sucuk
- Yumurta
- Domates
- Biber
- Soğan