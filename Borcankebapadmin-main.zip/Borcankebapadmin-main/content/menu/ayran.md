---
name: "Ayran"
description: "Geleneksel Türk ayranı - serinletici ve sağlıklı"
price: 8
category: "İçecekler"
image: "https://raw.githubusercontent.com/hakkurgithub/images/main/acik-ayran.jpg"
calories: 60
isVegetarian: true
isVegan: false
isGlutenFree: true
isActive: true
---

# Ayran

Geleneksel Türk ayranı - serinletici ve sağlıklı.

## İçindekiler
- Taze yoğurt
- Su
- Tuz