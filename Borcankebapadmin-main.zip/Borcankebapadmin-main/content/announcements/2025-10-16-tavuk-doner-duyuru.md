---
title: "Yeni Lezzet: Tavuk Döner!"
date: "2025-10-16T10:00:00.000Z"
isActive: true
priority: "yüksek"
---

# Yeni Lezzet: Tavuk Döner Menümüzde!

Sevgili müşterilerimiz,

Marine edilmiş tavuk göğsünden hazırlanan **sağlıklı döner alternatifimiz** artık menümüzde!

## Özellikler
- ✅ Daha az kalorili
- ✅ Protein açısından zengin
- ✅ Özel marine sosumuzla lezzetli
- ✅ Taze sebzelerle servis

**Fiyat**: Sadece 40₺

Hemen deneyin ve görüşlerinizi bizimle paylaşın!

*Karagöz Döner Ailesi*