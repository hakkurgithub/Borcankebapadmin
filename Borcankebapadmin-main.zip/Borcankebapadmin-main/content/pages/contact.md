---
title: "İletişim"
phone: "+90 (212) 555 0123"
whatsapp: "+90 (532) 555 0123"
address: |
  Şişli Mah. Cumhuriyet Cad. No: 45/A
  Şişli/İstanbul
email: "info@karagozdoner.com"
workingHours: |
  Pazartesi - Pazar: 10:00 - 23:00
  Hafta içi öğle arası: 12:00 - 14:00 yoğun saatler
mapUrl: "https://goo.gl/maps/example"
---

# İletişim Bilgileri

Bize ulaşmak için aşağıdaki iletişim kanallarını kullanabilirsiniz.

## 📍 Adres
**Şişli Mah. Cumhuriyet Cad. No: 45/A**  
Şişli/İstanbul

## 📞 Telefon
**Sabit Hat**: +90 (212) 555 0123  
**WhatsApp**: +90 (532) 555 0123

## 📧 E-posta
info@karagozdoner.com

## 🕒 Çalışma Saatleri
- **Pazartesi - Pazar**: 10:00 - 23:00
- **Öğle Yoğunluğu**: 12:00 - 14:00
- **Akşam Yoğunluğu**: 19:00 - 21:00

## 🚗 Ulaşım
- **Metro**: Şişli-Mecidiyeköy Metro İstasyonu (5 dk yürüme)
- **Otobüs**: Cumhuriyet Caddesi durağı
- **Otopark**: Yakınında ücretli otopark mevcuttur

## 📱 Sosyal Medya
- **Instagram**: @karagozdoner
- **Facebook**: Karagöz Döner Resmi
- **Twitter**: @karagozdoner

---

*Sorularınız için 7/24 WhatsApp hattımızdan bize ulaşabilirsiniz!*