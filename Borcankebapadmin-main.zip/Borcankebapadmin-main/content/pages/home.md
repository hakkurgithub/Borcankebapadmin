---
heroTitle: "Karagöz Döner'e Hoş Geldiniz"
heroSubtitle: "1985'ten beri geleneksel lezzetleri modern sunum anlayışıyla buluşturuyoruz. Taze malzemeler, özenli hazırlık ve unutulmaz tatlar için doğru adrestesiniz."
heroImage: "https://raw.githubusercontent.com/hakkurgithub/images/main/doner-kebap.jpg"
features:
  - title: "Taze ve Kaliteli"
    description: "Günlük taze malzemelerle hazırlanan döner ve kebaplarımız"
    icon: "🥩"
  - title: "Geleneksel Lezzet"
    description: "Üç kuşaktır sürdürülen aile tarifleriyle özgün tatlar"
    icon: "👨‍🍳"
  - title: "Hızlı Servis"
    description: "Sipariş ve paket servis seçenekleriyle hızlı teslimat"
    icon: "⚡"
  - title: "Hijyenik Ortam"
    description: "En yüksek temizlik standartlarında hazırlık ve sunum"
    icon: "✨"
---

# Ana Sayfa İçeriği

Bu içerik CMS üzerinden yönetilmektedir.